<table border="0" width="100%" cellpadding="2" height="12">
<tr>
<td width="100%">
      <h2 align=center> ͼ�����ϵͳ</h2>
    </td>
</tr>
<tr>
<td width="100%" height="6">
        <p align="center">
		<a href="index.html"><font color="#008000">������ҳ</font></a>
		<font color="#8EB4D9">|</font>
		<a href="adminlogin.php"><font color="#008000">����Ա��¼</font></a>
		<font color="#8EB4D9">|</font>
		<a href="login.php"><font color="#008000">�û�ע���¼</font></a>
        <font color="#8EB4D9">|</font>
		<a href="addbook.php"><font color="#008000">�������</font></a>
		<font color="#8EB4D9">|</font>
		<a href="borrow.php"><font color="#008000">����</font></a>
        <font color="#8EB4D9">|</font>
		<a href="return.php"><font color="#008000">��������</font></a>
        <font color="#8EB4D9">|</font>
		<a href="search.php"><font color="#008000">ͼ���ѯ</font></a>
        <font color="#8EB4D9">|</font>
		<a href="logout.php"><font color="#008000">�˳�</font></a>
    </td>
</tr>
<tr><td height=10></td></tr>
</table>

